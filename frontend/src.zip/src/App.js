import { useState, useRef, useEffect } from "react";
import "./App.css";

// Syntax highlight JSON
function highlightJson(json) {
  return json
    .replace(/("(\\u[a-zA-Z0-9]{4}|\\[^u]|[^\\"])*"(\s*:)?|\b(true|false|null)\b|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?)/g, (match) => {
      let cls = "num";
      if (/^"/.test(match)) cls = /:$/.test(match) ? "key" : "str";
      else if (/true|false/.test(match)) cls = "bool";
      else if (/null/.test(match)) cls = "null";
      return `<span class="${cls}">${match}</span>`;
    });
}

function App() {
  const [messages, setMessages] = useState([
    { sender: "bot", text: "Welcome to the eFIR System. Please describe the incident in detail so I can assist you in filing your First Information Report." }
  ]);
  const [input, setInput] = useState("");
  const [firData, setFirData] = useState({});
  const [state, setState] = useState(null);
  const [isTyping, setIsTyping] = useState(false);
  const chatBottomRef = useRef(null);

  useEffect(() => {
    chatBottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isTyping]);

  const sendMessage = async () => {
    if (!input.trim()) return;

    const userMessage = { sender: "user", text: input };
    setMessages(prev => [...prev, userMessage]);
    setInput("");
    setIsTyping(true);

    try {
      const res = await fetch("http://127.0.0.1:8000/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: input, state })
      });

      const data = await res.json();
      setFirData(data.fir);
      setState(data.state);
      setIsTyping(false);
      setMessages(prev => [...prev, { sender: "bot", text: data.reply }]);
    } catch (error) {
      console.error("Error:", error);
      setIsTyping(false);
      setMessages(prev => [...prev, {
        sender: "bot",
        text: "⚠ Connection error. Please ensure the server is running and try again."
      }]);
    }
  };

  const fieldCount = Object.keys(firData).length;
  const jsonString = JSON.stringify(firData, null, 2);

  return (
    <div className="app-container">

      {/* ─── HEADER ─── */}
      <header className="app-header">
        <div className="header-emblem">⚖</div>
        <div>
          <div className="header-title">eFIR Assistant</div>
          <div className="header-subtitle">Electronic First Information Report System</div>
        </div>
        <div className="header-badge">System Active</div>
      </header>

      {/* ─── LEFT: CHAT ─── */}
      <section className="chat-section">
        <div className="chat-box">
          {messages.map((msg, i) => (
            <div key={i}>
              <div className={`message-label`}>
                {msg.sender === "user" ? "You" : "eFIR Assistant"}
              </div>
              <div className={`message ${msg.sender}`}>
                {msg.text}
              </div>
            </div>
          ))}

          {isTyping && (
            <div>
              <div className="message-label">eFIR Assistant</div>
              <div className="message bot typing-indicator">
                <span></span><span></span><span></span>
              </div>
            </div>
          )}

          <div ref={chatBottomRef} />
        </div>

        <div className="input-box">
          <div className="input-wrapper">
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Describe the incident in detail…"
              onKeyDown={(e) => e.key === "Enter" && sendMessage()}
            />
          </div>
          <button className="send-btn" onClick={sendMessage}>
            Send ↑
          </button>
        </div>
      </section>

      {/* ─── DIVIDER ─── */}
      <div className="panel-divider" />

      {/* ─── RIGHT: JSON PANEL ─── */}
      <section className="json-section">
        <div className="json-header">
          <div className="json-icon">📋</div>
          <h3>FIR Report Data</h3>
          {fieldCount > 0 && (
            <span className="field-count">{fieldCount} field{fieldCount !== 1 ? "s" : ""}</span>
          )}
          <span className="json-tag">Live Preview</span>
        </div>

        <div className="json-panel">
          {fieldCount === 0 ? (
            <div className="json-empty">
              <div className="json-empty-icon">🗂</div>
              <p>FIR fields will populate as you describe the incident</p>
            </div>
          ) : (
            <pre dangerouslySetInnerHTML={{ __html: highlightJson(jsonString) }} />
          )}
        </div>
      </section>

    </div>
  );
}

export default App;