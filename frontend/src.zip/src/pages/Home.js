import { useNavigate } from "react-router-dom";

function Home() {
  const navigate = useNavigate();

  return (
    <div className="home-container">
      <div className="home-card">
        <h1>⚖ eFIR System</h1>
        <p>Fast & Secure FIR Filing Assistant</p>

        <button onClick={() => navigate("/auth")}>
          Get Started
        </button>
      </div>
    </div>
  );
}

export default Home;