import { useState, useRef, useEffect } from "react";

// JSON highlight
function highlightJson(json) {
  return json.replace(
    /("(\\u[a-zA-Z0-9]{4}|\\[^u]|[^\\"])*"(\s*:)?|\b(true|false|null)\b|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?)/g,
    (match) => {
      let cls = "num";
      if (/^"/.test(match)) cls = /:$/.test(match) ? "key" : "str";
      else if (/true|false/.test(match)) cls = "bool";
      else if (/null/.test(match)) cls = "null";
      return `<span class="${cls}">${match}</span>`;
    }
  );
}

function Chat() {

  // ✅ KEEP STATE INSIDE CHAT PAGE
  const [messages, setMessages] = useState([
    {
      sender: "bot",
      text: "Welcome to the eFIR System. Please describe the incident in detail."
    }
  ]);

  const [input, setInput] = useState("");
  const [firData, setFirData] = useState({});
  const [state, setState] = useState(null);
  const [isTyping, setIsTyping] = useState(false);

  const chatBottomRef = useRef(null);

  useEffect(() => {
    chatBottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isTyping]);

  // ✅ FIXED API CALL
  const sendMessage = async () => {
    if (!input.trim()) return;

    const userMessage = { sender: "user", text: input };
    setMessages(prev => [...prev, userMessage]);
    setInput("");
    setIsTyping(true);

    try {
      const res = await fetch("http://127.0.0.1:8000/chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          message: input,
          state: state   // 🔥 IMPORTANT: pass state
        })
      });

      // 🔥 HANDLE ERROR RESPONSE
      if (!res.ok) throw new Error("Server error");

      const data = await res.json();

      console.log("API Response:", data); // debug

      setFirData(data.fir || {});
      setState(data.state || null);

      setMessages(prev => [
        ...prev,
        { sender: "bot", text: data.reply || "No response" }
      ]);

    } catch (error) {
      console.error("Error:", error);

      setMessages(prev => [
        ...prev,
        {
          sender: "bot",
          text: "⚠ Server not responding. Check backend."
        }
      ]);
    }

    setIsTyping(false);
  };

  const fieldCount = Object.keys(firData).length;
  const jsonString = JSON.stringify(firData, null, 2);

  return (
    <div className="app-container">

      {/* HEADER */}
      <header className="app-header">
        <div className="header-emblem">⚖</div>
        <div>
          <div className="header-title">eFIR Assistant</div>
          <div className="header-subtitle">Electronic FIR System</div>
        </div>
        <div className="header-badge">System Active</div>
      </header>

      {/* CHAT */}
      <section className="chat-section">
        <div className="chat-box">

          {messages.map((msg, i) => (
            <div key={i}>
              <div className="message-label">
                {msg.sender === "user" ? "You" : "Assistant"}
              </div>
              <div className={`message ${msg.sender}`}>
                {msg.text}
              </div>
            </div>
          ))}

          {isTyping && (
            <div>
              <div className="message-label">Assistant</div>
              <div className="message bot typing-indicator">
                <span></span><span></span><span></span>
              </div>
            </div>
          )}

          <div ref={chatBottomRef} />
        </div>

        <div className="input-box">
          <div className="input-wrapper">
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Describe the incident..."
              onKeyDown={(e) => e.key === "Enter" && sendMessage()}
            />
          </div>

          <button className="send-btn" onClick={sendMessage}>
            Send ↑
          </button>
        </div>
      </section>

      {/* DIVIDER */}
      <div className="panel-divider" />

      {/* JSON */}
      <section className="json-section">
        <div className="json-header">
          <div className="json-icon">📋</div>
          <h3>FIR Report Data</h3>

          {fieldCount > 0 && (
            <span className="field-count">{fieldCount} fields</span>
          )}
        </div>

        <div className="json-panel">
          {fieldCount === 0 ? (
            <div className="json-empty">
              <div className="json-empty-icon">🗂</div>
              <p>FIR fields will appear here</p>
            </div>
          ) : (
            <pre dangerouslySetInnerHTML={{
              __html: highlightJson(jsonString)
            }} />
          )}
        </div>
      </section>

    </div>
  );
}

export default Chat;