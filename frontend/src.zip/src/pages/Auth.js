import { useNavigate } from "react-router-dom";

function Auth() {
  const navigate = useNavigate();

  return (
    <div className="login-container">
      <div className="login-card">
        <h2>Login / Register</h2>

        <input placeholder="Email" />
        <input placeholder="Password" type="password" />

        <button onClick={() => navigate("/chat")}>
          Continue
        </button>

        <button onClick={() => navigate("/")} className="back-btn">
          ← Back
        </button>
      </div>
    </div>
  );
}

export default Auth;